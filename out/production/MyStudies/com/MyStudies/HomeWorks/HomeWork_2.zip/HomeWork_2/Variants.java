package com.MyStudies.HomeWorks.HomeWork_2;

public enum Variants {
        ROCK,
        PAPER,
        SCISSORS
}
